<?php

namespace App\Controllers;

use App\Traits\Renderable;

class BaseController
{
    use Renderable;
}